#include "GameScene.h"
#include<DxLib.h>
#include<cassert>

#include"../Input.h"//���͗p
#include"SceneController.h"//�V�[���̐؂�ւ��Ɏg��
#include"OverScene.h"//���̃V�[��
#include"PauseScene.h"//�|�[�Y�V�[��
#include"../DrawUtil.h"

namespace {
	constexpr int fade_interval = 60;
	float DegreeToRadian(float degree) {
		//0�`360��0�`2��
		//0�`180��0�`��
		//��180 x ��
		return (degree * DX_PI_F) / 180.0f;
	}
}

void GameScene::FadeInUpdate(Input& input)
{
	if (--frame_ <= 0) {
		update_ = &GameScene::NormalUpdate;
		draw_ = &GameScene::NormalDraw;
	}
}

void GameScene::NormalUpdate(Input& input)
{
	++frame_;
	if (input.IsTriggered("ok")) {
		update_ = &GameScene::FadeOutUpdate;
		draw_ = &GameScene::FadeDraw;
		frame_ = 0;
		return;
	}
	if (input.IsTriggered("pause")) {
		controller_.PushScene(std::make_shared<PauseScene>(controller_));
		return;
	}
	if (input.IsPressed("up")) {
		cameraPos_.y += 0.1f;
	}
	if (input.IsPressed("down")) {
		cameraPos_.y -= 0.1f;
	}
	if (input.IsPressed("right")) {
		cameraPos_.x += 0.1f;
	}
	if (input.IsPressed("left")) {
		cameraPos_.x -= 0.1f;
	}
	if(input.IsTriggered("shot")){
		yureFrame_ = 360;
		yureRate_ = 1.0f;
	}
	if (yureFrame_ > 0) {
		yureRate_ *= 0.95f;
		--yureFrame_;
	}
	else {
		yureRate_ = 0.0f;
	}
	
}

void GameScene::FadeOutUpdate(Input& input)
{
	if (++frame_ >= fade_interval) {
		controller_.ChangeScene(std::make_shared<OverScene>(controller_));
		return;
	}
}

void GameScene::NormalDraw()
{
	SetDrawScreen(RT_);
	ClearDrawScreen();
	DrawRotaGraph(320, 240, 1.0f, 0.0f, imgH_, true);
	DrawString(10, 10, L"Game Scene", 0xffffff);
	constexpr float r = 100.0f;
	float angle = DX_PI_F*2.0f* static_cast<float>(frame_ % 360) / 36.0f;
	//DrawCircleAA(320+cos(angle) * r, 240+sin(angle) * r, 10, 32, 0xff8888, true);
	//DrawFormatString(10, 100, 0xffffff, L"FPS=%2.2f", GetFPS());

	int recordY = 100;
	constexpr int record_x = 100;

	SetupCamera_Perspective(DX_PI_F / 3.0f);//��p
	SetCameraNearFar(0.3f, 1000.0f);
	//SetCameraPositionAndTarget_UpVecY(
	//	VGet(cameraPos_.x, cameraPos_.y, cameraPos_.z),
	//	VGet(0,0,0));
	SetCameraPositionAndAngle(VGet(cameraPos_.x, cameraPos_.y, cameraPos_.z),
		0,0,0);

	for (const auto& model :models_) {
		MV1DrawModel(model);
	}

	SetDrawScreen(DX_SCREEN_BACK);
	int x = ((yureFrame_ % 3) * 20-10)*yureRate_;
	ClearDrawScreen();
	//if (yureFrame_ == 0) {
		x = 0;
	//}
	//if (yureFrame_ > 0) {
	//	GraphFilter(RT_, DX_GRAPH_FILTER_GAUSS, 32, 1400);
	//	GraphFilterBlt(RT_, RTSmall_, DX_GRAPH_FILTER_DOWN_SCALE, 4);
	//	GraphFilter(RTSmall_, DX_GRAPH_FILTER_GAUSS, 32, 1400);
	//	GraphFilter(RT_, DX_GRAPH_FILTER_GAUSS, 32, 1400);
	//	DrawExtendGraph(x, 0,x+640,480, RTSmall_, false);
	//	
	//	FillGraph(RTBloom_, 0, 0, 0, 255);
	//	FillGraph(RTSmall_, 0, 0, 0, 255);
	//	�܂����邢�����������o����RTBloom�ɃR�s�[����
	//	GraphFilterBlt(RT_,RTBloom_,DX_GRAPH_FILTER_BRIGHT_CLIP, DX_CMP_LESS, 250);
	//	RTBloom���k���o�b�t�@�ɃR�s�[����
	//	GraphFilterBlt(RTBloom_, RTSmall_, DX_GRAPH_FILTER_DOWN_SCALE, 4);
	//	RTBloom����яk���o�b�t�@�������ڂ���
	//	GraphFilter(RTSmall_, DX_GRAPH_FILTER_GAUSS, 32, 1400);
	//	GraphFilter(RTBloom_, DX_GRAPH_FILTER_GAUSS, 32, 1400);
	//	�ʏ�`��
	//	DrawGraph(x, 0, RT_, false);
	//	SetDrawBlendMode(DX_BLENDMODE_ADD, 255);//���Z����
	//	DrawGraph(x, 0, RTBloom_, true);//���P�x���ڂ������̂�`��
	//	DrawExtendGraph(x, 0, x + 640, 480, RTSmall_, false);//�k����`��
	//	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);//�߂�
	//}
	//else {
		DrawUtil::DrawGraph(x, 0,ps_, RT_,true);
	//}
	

}

void GameScene::FadeDraw()
{
	DrawRotaGraph(320, 240, 1.0f, 0.0f, imgH_, true);
	float rate = static_cast<float>(frame_) /
					static_cast<float>(fade_interval);
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, rate * 255);
	DrawBox(0, 0, 640, 480, 0x000000,true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
}

void GameScene::LoadLocationData()
{
	//�w�b�_�̃T�C�Y�͌Œ�
	struct Header {
		char signature[4];
		float version;
		int count;
	};
	Header header = {};
	auto fHandle=FileRead_open(L"./location.dat");
	FileRead_read(&header, sizeof(header), fHandle);
	locationData_.resize(header.count);
	for (auto& location : locationData_) {
		uint8_t nameSize = 0;
		FileRead_read(&nameSize, sizeof(nameSize), fHandle);
		location.name.resize(nameSize);
		FileRead_read(location.name.data(), location.name.size(), fHandle);
		FileRead_read(&location.pos, sizeof(location.pos), fHandle);
		FileRead_read(&location.angle, sizeof(location.angle), fHandle);
	}
	
	FileRead_close(fHandle);
}

GameScene::GameScene(SceneController& controller) :Scene(controller)
{
	imgH_=LoadGraph(L"img/brook.png");
	assert(imgH_ >= 0);
	update_ = &GameScene::FadeInUpdate;
	draw_ = &GameScene::FadeDraw;
	frame_ = fade_interval;
	LoadLocationData();
	//�v���g�^�C�v�p�^�[��
	int sphereProtoH = MV1LoadModel(L"model/model.mv1");
	int cubeProtoH = MV1LoadModel(L"model/bodyeater.mv1");
	int capsuleProtoH = MV1LoadModel(L"model/bat.mv1");
	models_.resize(locationData_.size());
	for (int i = 0; i < locationData_.size();++i) {
		constexpr float model_scale = 0.004f;
		if (locationData_[i].name == "Cube") {
			models_[i] = MV1DuplicateModel(cubeProtoH);
			MV1SetScale(models_[i], VGet(0.01, 0.01, 0.01));
		}
		else if(locationData_[i].name == "Sphere") {
			models_[i] = MV1DuplicateModel(sphereProtoH);
			MV1SetScale(models_[i], VGet(model_scale, model_scale, model_scale));
		}
		else if (locationData_[i].name == "Capsule") {
			models_[i] = MV1DuplicateModel(capsuleProtoH);
			MV1SetScale(models_[i], VGet(model_scale, model_scale, model_scale));
		}

		const auto& pos = locationData_[i].pos;
		const auto& rot = locationData_[i].angle;
		
		MV1SetRotationXYZ(models_[i],
			VGet(DegreeToRadian(rot.x), 
				DegreeToRadian(rot.y), 
				DegreeToRadian(rot.z)));
		MV1SetPosition(models_[i], VGet(pos.x, pos.y, pos.z));
	}
	MV1DeleteModel(capsuleProtoH);
	MV1DeleteModel(sphereProtoH);
	MV1DeleteModel(cubeProtoH);

	cameraPos_ = { 0.0f,1.0f,-10.0f };

	int sw, sh, depth;
	GetScreenState(&sw, &sh, &depth);

	RT_=MakeScreen(sw, sh);//�����_�[�^�[�Q�b�g
	RTBloom_ = MakeScreen(sw, sh);//�����_�[�^�[�Q�b�g
	RTSmall_ = MakeScreen(sw / 4, sh / 4);//�k���o�b�t�@
	ps_=LoadPixelShader(L"PixelShader.pso");//�s�N�Z���V�F�[�_�̃��[�h
	assert(ps_ >= 0);
}

GameScene::~GameScene()
{
	for (auto model : models_) {
		MV1DeleteModel(model);
	}
	DeleteGraph(imgH_);
	DeleteGraph(RT_);
	DeleteGraph(RTSmall_);
}

void GameScene::Update(Input& input)
{
	(this->*update_)(input);
}

void GameScene::Draw()
{
	(this->*draw_)();
}
