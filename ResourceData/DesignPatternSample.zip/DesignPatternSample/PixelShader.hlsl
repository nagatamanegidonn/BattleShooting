
Texture2D tex : register(t0);
SamplerState smp : register(s0);

struct PixelInput {
	float4 pos:SV_POSITION;
	float4 col:COLOR0;
	float4 spc:COLOR1;
	float2 uv:TEXCOORD0;
	float2 subUV:TEXCOORD1;
};

float4 main(PixelInput input) : SV_TARGET
{
	return tex.Sample(smp,input.uv).gbra;
}