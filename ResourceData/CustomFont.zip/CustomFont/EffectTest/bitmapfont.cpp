#include "bitmapfont.h"
#include<DxLib.h>
#include<algorithm>


BmpFont::BmpFont()
{
	bmpfontdata_[33] = { 341   ,131   ,9     ,31    ,1     ,1 };
	bmpfontdata_[34] = { 375   ,192   ,11    ,11    ,0     ,3 };
	bmpfontdata_[35] = { 414   ,162   ,16    ,29    ,0     ,2 };
	bmpfontdata_[36] = { 243   ,131   ,16    ,31    ,0     ,1 };
	bmpfontdata_[37] = { 431   ,162   ,16    ,29    ,0     ,2 };
	bmpfontdata_[38] = { 277   ,131   ,16    ,31    ,0     ,1 };
	bmpfontdata_[39] = { 504   ,161   ,7     ,10    ,1     ,3 };
	bmpfontdata_[40] = { 465   ,162   ,12    ,29    ,2     ,2 };
	bmpfontdata_[41] = { 311   ,131   ,14    ,31    ,1     ,1 };
	bmpfontdata_[42] = { 0     ,195   ,16    ,28    ,0     ,2 };
	bmpfontdata_[43] = { 448   ,162   ,16    ,29    ,0     ,2 };
	bmpfontdata_[44] = { 387   ,192   ,7     ,9     ,1     ,20 };
	bmpfontdata_[45] = { 395   ,192   ,14    ,8     ,1     ,11 };
	bmpfontdata_[46] = { 410   ,192   ,5     ,5     ,1     ,24 };
	bmpfontdata_[47] = { 215   ,193   ,14    ,25    ,0     ,5 };
	bmpfontdata_[48] = { 145   ,163   ,15    ,30    ,0     ,1 };
	bmpfontdata_[49] = { 96    ,67    ,11    ,32    ,1     ,0 };
	bmpfontdata_[50] = { 161   ,163   ,14    ,30    ,1     ,2 };
	bmpfontdata_[51] = { 326   ,131   ,14    ,31    ,0     ,1 };
	bmpfontdata_[52] = { 79    ,67    ,16    ,32    ,0     ,0 };
	bmpfontdata_[53] = { 260   ,131   ,16    ,31    ,0     ,1 };
	bmpfontdata_[54] = { 226   ,131   ,16    ,31    ,0     ,1 };
	bmpfontdata_[55] = { 127   ,164   ,17    ,30    ,-1    ,2 };
	bmpfontdata_[56] = { 294   ,131   ,16    ,31    ,0     ,0 };
	bmpfontdata_[57] = { 209   ,131   ,16    ,31    ,0     ,1 };
	bmpfontdata_[8531] = { 488   ,191   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8532] = { 484   ,191   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8533] = { 238   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8534] = { 472   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8535] = { 464   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8536] = { 456   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8537] = { 448   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8538] = { 444   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8539] = { 436   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8540] = { 432   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8541] = { 428   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8542] = { 424   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8543] = { 420   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8544] = { 187   ,131   ,21    ,31    ,6     ,1 };
	bmpfontdata_[8545] = { 140   ,131   ,23    ,31    ,5     ,1 };
	bmpfontdata_[8546] = { 86    ,132   ,26    ,31    ,3     ,1 };
	bmpfontdata_[8547] = { 35    ,0     ,33    ,33    ,0     ,0 };
	bmpfontdata_[8548] = { 197   ,99    ,31    ,31    ,1     ,1 };
	bmpfontdata_[8549] = { 0     ,34    ,34    ,32    ,-1    ,0 };
	bmpfontdata_[8550] = { 443   ,0     ,34    ,32    ,-1    ,1 };
	bmpfontdata_[8551] = { 474   ,66    ,32    ,31    ,0     ,1 };
	bmpfontdata_[8552] = { 102   ,0     ,32    ,33    ,0     ,0 };
	bmpfontdata_[8553] = { 35    ,34    ,32    ,32    ,0     ,1 };
	bmpfontdata_[8554] = { 270   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8555] = { 266   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8556] = { 254   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8557] = { 250   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8558] = { 246   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8559] = { 242   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8560] = { 234   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8561] = { 230   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8562] = { 508   ,172   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8563] = { 504   ,172   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8564] = { 258   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8565] = { 500   ,191   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8566] = { 496   ,191   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8567] = { 492   ,191   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8568] = { 480   ,191   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8569] = { 468   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8570] = { 476   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8571] = { 460   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8572] = { 452   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8573] = { 440   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8574] = { 416   ,192   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8575] = { 507   ,66    ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8576] = { 278   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8577] = { 274   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[8578] = { 262   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[12353] = { 115   ,195   ,25    ,25    ,0     ,7 };
	bmpfontdata_[12354] = { 177   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12355] = { 255   ,193   ,24    ,23    ,0     ,9 };
	bmpfontdata_[12356] = { 275   ,163   ,31    ,29    ,0     ,3 };
	bmpfontdata_[12357] = { 75    ,195   ,18    ,27    ,1     ,5 };
	bmpfontdata_[12358] = { 486   ,33    ,25    ,32    ,2     ,0 };
	bmpfontdata_[12359] = { 393   ,162   ,20    ,29    ,1     ,3 };
	bmpfontdata_[12360] = { 54    ,67    ,24    ,32    ,3     ,0 };
	bmpfontdata_[12361] = { 50    ,195   ,24    ,27    ,1     ,5 };
	bmpfontdata_[12362] = { 332   ,34    ,31    ,32    ,1     ,0 };
	bmpfontdata_[12363] = { 201   ,0     ,32    ,33    ,0     ,0 };
	bmpfontdata_[12364] = { 299   ,34    ,32    ,32    ,0     ,1 };
	bmpfontdata_[12365] = { 30    ,132   ,27    ,31    ,0     ,1 };
	bmpfontdata_[12366] = { 134   ,34    ,32    ,32    ,0     ,0 };
	bmpfontdata_[12367] = { 164   ,131   ,22    ,31    ,0     ,1 };
	bmpfontdata_[12368] = { 293   ,99    ,30    ,31    ,1     ,1 };
	bmpfontdata_[12369] = { 68    ,34    ,32    ,32    ,0     ,0 };
	bmpfontdata_[12370] = { 478   ,0     ,32    ,32    ,0     ,0 };
	bmpfontdata_[12371] = { 369   ,162   ,23    ,29    ,1     ,2 };
	bmpfontdata_[12372] = { 307   ,163   ,30    ,29    ,1     ,2 };
	bmpfontdata_[12373] = { 427   ,34    ,29    ,32    ,1     ,1 };
	bmpfontdata_[12374] = { 200   ,34    ,32    ,32    ,0     ,1 };
	bmpfontdata_[12375] = { 483   ,130   ,27    ,30    ,1     ,1 };
	bmpfontdata_[12376] = { 97    ,164   ,29    ,30    ,0     ,1 };
	bmpfontdata_[12377] = { 135   ,0     ,32    ,33    ,0     ,0 };
	bmpfontdata_[12378] = { 168   ,0     ,32    ,33    ,0     ,0 };
	bmpfontdata_[12379] = { 417   ,131   ,32    ,30    ,0     ,1 };
	bmpfontdata_[12380] = { 450   ,131   ,32    ,30    ,0     ,1 };
	bmpfontdata_[12381] = { 448   ,99    ,30    ,31    ,1     ,1 };
	bmpfontdata_[12382] = { 229   ,99    ,31    ,31    ,1     ,1 };
	bmpfontdata_[12383] = { 267   ,0     ,31    ,33    ,1     ,0 };
	bmpfontdata_[12384] = { 233   ,34    ,32    ,32    ,0     ,0 };
	bmpfontdata_[12385] = { 299   ,0     ,31    ,33    ,0     ,0 };
	bmpfontdata_[12386] = { 0     ,0     ,34    ,33    ,-1    ,0 };
	bmpfontdata_[12387] = { 141   ,195   ,25    ,25    ,1     ,7 };
	bmpfontdata_[12388] = { 479   ,98    ,30    ,31    ,1     ,1 };
	bmpfontdata_[12389] = { 108   ,67    ,34    ,31    ,-1    ,1 };
	bmpfontdata_[12390] = { 386   ,99    ,30    ,31    ,1     ,1 };
	bmpfontdata_[12391] = { 143   ,67    ,33    ,31    ,-1    ,1 };
	bmpfontdata_[12392] = { 457   ,33    ,28    ,32    ,2     ,0 };
	bmpfontdata_[12393] = { 396   ,34    ,30    ,32    ,2     ,0 };
	bmpfontdata_[12394] = { 266   ,34    ,32    ,32    ,0     ,0 };
	bmpfontdata_[12395] = { 338   ,163   ,30    ,29    ,0     ,2 };
	bmpfontdata_[12396] = { 210   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12397] = { 243   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12398] = { 99    ,100   ,32    ,31    ,0     ,1 };
	bmpfontdata_[12399] = { 331   ,0     ,30    ,33    ,1     ,0 };
	bmpfontdata_[12400] = { 364   ,34    ,31    ,32    ,1     ,0 };
	bmpfontdata_[12401] = { 234   ,0     ,32    ,33    ,1     ,0 };
	bmpfontdata_[12402] = { 209   ,163   ,32    ,29    ,0     ,2 };
	bmpfontdata_[12403] = { 384   ,131   ,32    ,30    ,0     ,1 };
	bmpfontdata_[12404] = { 0     ,164   ,32    ,30    ,0     ,1 };
	bmpfontdata_[12405] = { 33    ,100   ,32    ,31    ,0     ,1 };
	bmpfontdata_[12406] = { 0     ,100   ,32    ,31    ,0     ,1 };
	bmpfontdata_[12407] = { 375   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12408] = { 17    ,195   ,32    ,27    ,0     ,3 };
	bmpfontdata_[12409] = { 176   ,163   ,32    ,29    ,0     ,1 };
	bmpfontdata_[12410] = { 242   ,163   ,32    ,29    ,0     ,1 };
	bmpfontdata_[12411] = { 355   ,99    ,30    ,31    ,1     ,1 };
	bmpfontdata_[12412] = { 276   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12413] = { 165   ,99    ,31    ,31    ,1     ,1 };
	bmpfontdata_[12414] = { 418   ,0     ,24    ,33    ,2     ,0 };
	bmpfontdata_[12415] = { 408   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12416] = { 66    ,164   ,30    ,30    ,1     ,1 };
	bmpfontdata_[12417] = { 441   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12418] = { 0     ,67    ,27    ,32    ,1     ,1 };
	bmpfontdata_[12419] = { 167   ,194   ,25    ,25    ,0     ,7 };
	bmpfontdata_[12420] = { 101   ,34    ,32    ,32    ,0     ,0 };
	bmpfontdata_[12421] = { 280   ,193   ,22    ,23    ,1     ,9 };
	bmpfontdata_[12422] = { 261   ,99    ,31    ,31    ,0     ,1 };
	bmpfontdata_[12423] = { 193   ,193   ,21    ,25    ,1     ,7 };
	bmpfontdata_[12424] = { 58    ,132   ,27    ,31    ,0     ,1 };
	bmpfontdata_[12425] = { 28    ,67    ,25    ,32    ,1     ,0 };
	bmpfontdata_[12426] = { 478   ,162   ,25    ,28    ,1     ,2 };
	bmpfontdata_[12427] = { 113   ,132   ,26    ,31    ,1     ,1 };
	bmpfontdata_[12428] = { 132   ,99    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12429] = { 362   ,0     ,28    ,33    ,1     ,0 };
	bmpfontdata_[12430] = { 230   ,193   ,24    ,23    ,0     ,8 };
	bmpfontdata_[12431] = { 351   ,131   ,32    ,30    ,0     ,1 };
	bmpfontdata_[12432] = { 167   ,34    ,32    ,32    ,0     ,1 };
	bmpfontdata_[12433] = { 417   ,99    ,30    ,31    ,1     ,1 };
	bmpfontdata_[12434] = { 391   ,0     ,26    ,33    ,1     ,0 };
	bmpfontdata_[12435] = { 309   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[12436] = { 282   ,217   ,3     ,1     ,-1    ,32 };
	bmpfontdata_[12443] = { 344   ,193   ,16    ,14    ,1     ,1 };
	bmpfontdata_[12444] = { 361   ,193   ,13    ,12    ,2     ,3 };
	bmpfontdata_[12445] = { 303   ,193   ,20    ,22    ,1     ,5 };
	bmpfontdata_[12446] = { 324   ,193   ,19    ,22    ,1     ,5 };
	bmpfontdata_[20307] = { 342   ,67    ,32    ,31    ,0     ,1 };
	bmpfontdata_[21147] = { 0     ,132   ,29    ,31    ,2     ,1 };
	bmpfontdata_[21566] = { 324   ,99    ,30    ,31    ,1     ,1 };
	bmpfontdata_[27531] = { 33    ,164   ,32    ,30    ,0     ,1 };
	bmpfontdata_[29483] = { 66    ,100   ,32    ,31    ,0     ,1 };
	bmpfontdata_[36649] = { 69    ,0     ,32    ,33    ,0     ,0 };
	bmpfontdata_[65309] = { 94    ,195   ,20    ,26    ,1     ,3 };
	bmpFont_ = LoadGraph(L"zonji.png");
}

void BmpFont::DrawString(int x, int y , const std::wstring& text)
{

	for (size_t i = 0; i < text.size(); ++i) {
		int unicode = text[i];
		if (bmpfontdata_.contains(unicode)) {
			const auto& bmpfontdata = bmpfontdata_.at(unicode);
			DrawRectGraph(x + bmpfontdata.offsetX, 100 + bmpfontdata.offsetY,
				bmpfontdata.x, bmpfontdata.y,
				bmpfontdata.width, bmpfontdata.height, bmpFont_, TRUE);
			x += bmpfontdata.width + bmpfontdata.offsetX;
		}
	}
}
