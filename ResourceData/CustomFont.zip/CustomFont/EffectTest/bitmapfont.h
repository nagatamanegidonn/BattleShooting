#pragma once

#include<map>
#include<string>
struct BmpFontData{
	int x;
	int y;
	int width;
	int height;
	int offsetX;
	int offsetY;
};

class BmpFont {
private:
	std::map<int, BmpFontData> bmpfontdata_;
	int bmpFont_;
public:
	BmpFont();
	void DrawString(int x, int y , const std::wstring& str);
};