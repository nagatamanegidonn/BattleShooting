#include<DxLib.h>
#include<string>
#include<sstream>
#include"bitmapfont.h"

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
	ChangeWindowMode(TRUE);
	SetGraphMode(640, 480, 32);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);

	
	int frame = 0;

	BmpFont bmpFont;
	while (ProcessMessage() == 0) {
		ClearDrawScreen();
		std::wostringstream strSteam;
		strSteam << L"�c��̗́�" << frame;
		++frame;
		auto text = strSteam.str();
		
		bmpFont.DrawString(100, 100, text);

		ScreenFlip();
	}
	DxLib_End();
	return 0;
}